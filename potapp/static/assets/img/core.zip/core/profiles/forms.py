from django import forms
from .models import profile
from bootstrap_datepicker_plus.widgets import DatePickerInput, TimePickerInput, DateTimePickerInput, MonthPickerInput, YearPickerInput


GENDER_CHOICES = [
    ('MALE', "Male"),
    ("FEMALE", "Female")
]

Interest_Choice = [
    ('HTML', 'HTML'),
    ('css', 'CSS'), ('JavaScript', 'javascript'), ('PHP','PHP')
]

class profileForm(forms.ModelForm):
    gender = forms.ChoiceField(choices = GENDER_CHOICES, widget = forms.RadioSelect())
    skills = forms.MultipleChoiceField(choices = Interest_Choice, widget=forms.CheckboxSelectMultiple)
    dob = forms.DateField(widget=forms.SelectDateWidget)
    class Meta:
        model = profile
        fields = ['name', 'dob','gender', 'pin', 'phone', 'mail', 'state', 'skills', 'img']
        labels = {'name':'NAME', 'dob': 'Birthdate', 'gender':'Identifier',
                  'pin': 'PIN Code', 'phone':'Mobile Number', 'mail': 'G-MAIL ID(only)', 'state':'REGION', 
                  'skills': 'INTERESTS', 'img':'Profile Image'}
        widgets = {
            'name' : forms.TextInput(),
            'dob' : forms.DateInput(),
            'gender' : forms.Select(),
            'mail' : forms.EmailInput(),
            'state' : forms.Select(),
           
            
        }