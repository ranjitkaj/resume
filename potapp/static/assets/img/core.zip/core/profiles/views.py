from django.shortcuts import render
from .models import *
from .forms import *

def pview(request):
    fm = profileForm(request.POST, request.FILES)
    if fm.is_valid():
        fm.save()
    else:pass
    return render(request, 'index.html', {'form':fm })

# Create your views here.
