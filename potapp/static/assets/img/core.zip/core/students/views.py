from django.shortcuts import render
from .models import *
from .forms import *

def create(request):
    fm = registrationForm(request.POST, request.FILES)
    data = registration.objects.all()
    if fm.is_valid():
        fm.save()
    else:pass
    return render(request, 'index.html', {'form':fm, 'data':data })
    
    
#def read(request):
 #   data = registration.objects.all()
  #  return render(request, 'read.html', {'data':data})

# Create your views here.
